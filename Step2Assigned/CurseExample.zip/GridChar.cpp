#include "GridChar.h"

GridChar::GridChar(char _display) : display(_display) {}

char GridChar::getChar() {
	return display;
}
